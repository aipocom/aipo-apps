package com.jsonengine.http;

import javax.servlet.http.HttpServlet;

/**
 * Provides REST API for jsonengine query operations.
 * 
 * @author @kazunori_279
 */
public class QueryServlet extends HttpServlet {

    
}
